package console;

public class Console {

	
	public static void main(String[] args) {
		
	}
	
	
	public String nomeconsole;
	public int idconsole;		
	public int anodelançamento;
	public String proprietaria;
	public String getNomeconsole() {
		return nomeconsole;
	}
	public void setNomeconsole(String nomeconsole) {
		this.nomeconsole = nomeconsole;
	}
	public int getIdconsole() {
		return idconsole;
	}
	public void setIdconsole(int idconsole) {
		this.idconsole = idconsole;
	}
	public int getAnodelançamento() {
		return anodelançamento;
	}
	public void setAnodelançamento(int anodelançamento) {
		this.anodelançamento = anodelançamento;
	}
	public String getProprietaria() {
		return proprietaria;
	}
	public void setProprietaria(String proprietaria) {
		this.proprietaria = proprietaria;
	}
	
	
	
	
	
	
	
		

}