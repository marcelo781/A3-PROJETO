package jogo;

public class Jogo {

	public static void main(String[] args) {
	}
		public String nomejogo;
		public int idjogo;
		public int anodelançamento;
		public String proprietaria;
		public String genero;
		public int preco;
		public String getNomejogo() {
			return nomejogo;
		}
		public void setNomejogo(String nomejogo) {
			this.nomejogo = nomejogo;
		}
		public int getIdjogo() {
			return idjogo;
		}
		public void setIdjogo(int idjogo) {
			this.idjogo = idjogo;
		}
		public int getAnodelançamento() {
			return anodelançamento;
		}
		public void setAnodelançamento(int anodelançamento) {
			this.anodelançamento = anodelançamento;
		}
		public String getProprietaria() {
			return proprietaria;
		}
		public void setProprietaria(String proprietaria) {
			this.proprietaria = proprietaria;
		}
		public String getGenero() {
			return genero;
		}
		public void setGenero(String genero) {
			this.genero = genero;
		}
		public int getPreco() {
			return preco;
		}
		public void setPreco(int preco) {
			this.preco = preco;
		}
		
		
		
		
		
	}
	
	

