package perfil;

public class Perfil {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

		private String nomecliente;
		private int idade; 
		private int id; 
		private String jogofavorito;
		private String nacionalidade;
		private int quantconquistas;
		private String timedocoracao;
		public String getNomecliente() {
			return nomecliente;
		}
		public void setNomecliente(String nomecliente) {
			this.nomecliente = nomecliente;
		}
		public int getIdade() {
			return idade;
		}
		public void setIdade(int idade) {
			this.idade = idade;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getJogofavorito() {
			return jogofavorito;
		}
		public void setJogofavorito(String jogofavorito) {
			this.jogofavorito = jogofavorito;
		}
		public String getNacionalidade() {
			return nacionalidade;
		}
		public void setNacionalidade(String nacionalidade) {
			this.nacionalidade = nacionalidade;
		}
		public int getQuantconquistas() {
			return quantconquistas;
		}
		public void setQuantconquistas(int quantconquistas) {
			this.quantconquistas = quantconquistas;
		}
		public String getTimedocoracao() {
			return timedocoracao;
		}
		public void setTimedocoracao(String timedocoracao) {
			this.timedocoracao = timedocoracao;
		}

			
		
	
		
		
	



		}
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

