package packapp;

import java.sql.Connection;

import com.mysql.cj.jdbc.JdbcPreparedStatement;

import perfil.Perfil;
import projetoDAO.ProjetoDao;


public class Mainappsalvardados {

	public static void main(String[] args) {
	
	// MVC
	// MODEL
	// VIEW
	// CONTROLLER 
	
	ProjetoDao projetoDao = new ProjetoDao();
	
	
	Perfil perfil = new Perfil();
	perfil.setNomecliente("Marcelo3");
	perfil.setIdade(23);
	perfil.setJogofavorito("Persona 5");
	perfil.setNacionalidade("Brasileiro");
	perfil.setQuantconquistas(65);
	perfil.setTimedocoracao("Corinthians");
	
	 projetoDao.save(perfil);     // SE ISSO AQUI DEIXAR DE SER COMENTADO, VAI SALVAR UM PERFIL
	
	// ATUALIZAR O CONTATO
	
	Perfil p1 = new Perfil();

	p1.setNomecliente("Marcelo");
	p1.setIdade(22);
	p1.setJogofavorito("Persona 5");
	p1.setNacionalidade("Brasileiro");
	p1.setQuantconquistas(60);
	p1.setTimedocoracao("Corinthians");
	
	 p1.setId(2);  //NUMERO DO ID NO BANCO DE DADOS 
	 
	// projetoDao.update(p1);        // SE ISSO AQUI DEIXAR DE SER COMENTADO, VAI ATUALIZAR UM PERFIL	
	
	
	//DELETAR UM CONTATO PELO SEU NUMERO DE ID
	
	//	projetoDao.deleteByID(1);      // SE ISSO AQUI DEIXAR DE SER COMENTADO, VAI DELETAR UM PERFIL PELO ID
	
	
	
	
	
	
	// VISUALIZA��O DOS REGISTROS NO BANCO 
	
	for(Perfil p : projetoDao.getPerfis());
	
	System.out.println("Perfil: "+ perfil.getNomecliente());

}
	

















}
	
	
	
	
	
	
	
	
	
	
	

